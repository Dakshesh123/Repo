class Dashboard::HomeController < Dashboard::BaseController
  def index
  end
end
