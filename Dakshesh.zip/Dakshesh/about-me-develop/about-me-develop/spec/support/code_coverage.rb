require "simplecov"
SimpleCov.start "rails"

require "codecov"
SimpleCov.formatter = SimpleCov::Formatter::Codecov
