# README

Getting Started!

Just kidding, I'll update more later.....

* Ruby : `2.5.1`
* System dependencies : `Gemfiles`
* Databse : `Postgres 10`
* DB init run `rake db:create` then `rake db:migrate`
* Test : run `./bin/rspec`
* Deployment instructions(TODO)
